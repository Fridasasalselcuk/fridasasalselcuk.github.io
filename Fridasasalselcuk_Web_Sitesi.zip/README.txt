FRİDAŞAŞALSELÇUK WEB SİTESİ

Dosya adı: index.html
Bu site Frida Şaşal Selçuk adıyla hazırlanmıştır.
Alan adı olarak fridasasalselcuk şeklinde bir alan adı kullanılacaksa uygun uzantının (.com.tr, .com vb.) ayrıca satın alınması gerekir.
